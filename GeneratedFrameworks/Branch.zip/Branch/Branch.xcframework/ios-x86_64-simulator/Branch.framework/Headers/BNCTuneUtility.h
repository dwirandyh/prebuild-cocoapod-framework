//
//  BNCTuneUtility.h
//  Branch
//
//  Created by Ernest Cho on 10/4/19.
//  Copyright © 2019 Branch, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BNCTuneUtility : NSObject

+ (BOOL)isTuneDataPresent;

@end

NS_ASSUME_NONNULL_END
