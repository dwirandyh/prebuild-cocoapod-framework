//
//  UIStoryboard+Swizzling.h
//  SwinjectStoryboard
//
//  Created by Mark DiFranco on 2017-03-31.
//  Copyright © 2017 Swinject Contributors. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIStoryboard (Swizzling)

@end
