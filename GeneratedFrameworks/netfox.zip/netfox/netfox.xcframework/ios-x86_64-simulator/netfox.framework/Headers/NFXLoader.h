//
//  NFXLoader.h
//  netfox
//
//  Copyright © 2017 kasketis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NFXLoader : NSObject

@end
